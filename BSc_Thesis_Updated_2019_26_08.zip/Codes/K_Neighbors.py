import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import Normalizer
from sklearn.linear_model import LinearRegression


IAF = pd.read_csv('IAF2.csv')
#print(IAF)
X = IAF[['OpenInt', 'High', 'Low', 'Open', 'Volume']]
y = IAF['Close']
#X = X.drop(['Low', 'OpenInt'])

plt.figure()
plt.plot(y)
plt.title('Iran Aluminium Stock Price')
plt.ylabel('Price')
plt.xlabel('Dates')
#plt.legend(['Prediction', 'Real'], loc='upper left')
plt.show()

#_train = IAF[:10000]
#d_test = IAF[10000:]

X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.7, shuffle=False)
#print(y_test)
#print(X_test)

'''scaler = Normalizer().fit(X_train)
normalized_X = scaler.transform(X_train)
normalized_X_test = scaler.transform(X_test)
#print(normalized_X_test)'''

from sklearn import neighbors
knn = neighbors.KNeighborsClassifier(n_neighbors=15) #5

knn.fit(X, y)

y_pred = knn.predict(X_test)

print(y_pred,y_test)
plt.figure()
plt.plot(y_pred)
plt.plot(y_test)
plt.title('Prediction vs Real Stock Price - K Neighbors')
plt.ylabel('Price')
plt.xlabel('Dates')
plt.legend(['Prediction', 'Real'], loc='upper left')
plt.show()

from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import explained_variance_score
from dit.other import renyi_entropy

def mean_absolute_percentage_error(y_test, y_pred):
    return np.mean(np.abs((y_test - y_pred) / y_test)) * 100

def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())

#re = renyi_entropy(y_pred, 0)
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
mape = mean_absolute_percentage_error(y_test,y_pred)
evs = explained_variance_score(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
rmse = rmse(y_test, y_pred) #root of mse
print( mse, evs, mae, mape, rmse, r2)

from scipy.stats import kurtosis
kurt = kurtosis(y_test)
kurtp = kurtosis(y_pred)
print(kurt,kurtp)

from dit.other import renyi_entropy
'''renyi = renyi_entropy(y_test, order = 1)
renyip = renyi_entropy(y_pred, order = 1)
print(renyi, renyip)'''

from scipy.stats import entropy
entr = entropy(y_test)
entrp = entropy(y_pred)
print(entr, entrp)

from math import log, e

def entropy3(labels, base=None):
  vc = pd.Series(labels).value_counts(normalize=True, sort=False)
  base = e if base is None else base
  return -(vc * np.log(vc)/np.log(base)).sum()

ent3 = entropy3(y_test)
ent3p = entropy3(y_pred)
print(ent3, ent3p)

def entropy4(labels, base=None):
  value,counts = np.unique(labels, return_counts=True)
  norm_counts = counts / counts.sum()
  base = e if base is None else base
  return -(norm_counts * np.log(norm_counts)/np.log(base)).sum()

ent4 = entropy4(y_test)
ent4p = entropy4(y_pred)
print(ent4, ent4p)