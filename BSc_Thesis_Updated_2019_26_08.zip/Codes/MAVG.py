import pandas as pd
import numpy as np
import datetime
import pandas_datareader.data as web
from pandas import Series, DataFrame



start = datetime.datetime(2010, 1, 1)
end = datetime.datetime(2017, 1, 11)

df = pd.read_csv('IAF2.csv')
#print(IAF)
X = df[['OpenInt', 'High', 'Low', 'Open', 'Volume']]
y = df['Close']

#df = web.DataReader("AAPL", 'yahoo', start, end)
#df.tail()
#print(df.head())


close_px = df['Close']
mavg = close_px.rolling(window=10).mean() # window = 100

import matplotlib.pyplot as plt
from matplotlib import style

# Adjusting the size of matplotlib
import matplotlib as mpl
mpl.rc('figure', figsize=(8, 7))
mpl.__version__

# Adjusting the style of matplotlib
style.use('ggplot')

close_px.plot(label='AAPL')
mavg.plot(label='mavg')
plt.title('Prediction vs Real Stock Price - Traditional Moving Average')
plt.legend()
plt.show()
rets = close_px / close_px.shift(1) - 1
rets.plot(label='return')

#y_pred = mavg[99:]
#y_test = close_px[99:]

y_pred = mavg[199:]
y_test = close_px[199:]

from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import explained_variance_score
from dit.other import renyi_entropy

def mean_absolute_percentage_error(y_test, y_pred):
    return np.mean(np.abs((y_test - y_pred) / y_test)) * 100

def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())

#re = renyi_entropy(y_pred, 0)
mse = mean_squared_error(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
mape = mean_absolute_percentage_error(y_test,y_pred)
evs = explained_variance_score(y_test, y_pred) # hamoon information gain
r2 = r2_score(y_test, y_pred)
rmse = rmse(y_test, y_pred) #root of mse
print( mse, evs, mae, mape, rmse, r2)

#print(y_pred)

from scipy.stats import kurtosis
kurt = kurtosis(y_test)
kurtp = kurtosis(y_pred)
print(kurt,kurtp)

from dit.other import renyi_entropy
'''renyi = renyi_entropy(y_test, order = 1)
renyip = renyi_entropy(y_pred, order = 1)
print(renyi, renyip)'''

from scipy.stats import entropy
entr = entropy(y_test)
entrp = entropy(y_pred)
print(entr, entrp)

from math import log, e

def entropy3(labels, base=None):
  vc = pd.Series(labels).value_counts(normalize=True, sort=False)
  base = e if base is None else base
  return -(vc * np.log(vc)/np.log(base)).sum()

ent3 = entropy3(y_test)
ent3p = entropy3(y_pred)
print(ent3, ent3p)

def entropy4(labels, base=None):
  value,counts = np.unique(labels, return_counts=True)
  norm_counts = counts / counts.sum()
  base = e if base is None else base
  return -(norm_counts * np.log(norm_counts)/np.log(base)).sum()

ent4 = entropy4(y_test)
ent4p = entropy4(y_pred)
print(ent4, ent4p)