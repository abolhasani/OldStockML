from numpy import loadtxt
from keras.models import Sequential
from keras.layers import Dense
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
# Tensorflow


IAF = pd.read_csv('IAF2.csv')
#print(IAF)
X = IAF[['OpenInt', 'High', 'Low', 'Open', 'Volume']]
y = IAF['Close']

X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.7, shuffle=False)

# define the keras model
model = Sequential()
model.add(Dense(12, input_dim=5, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# compile the keras model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# fit the keras model on the dataset
model.fit(X, y, epochs=10, batch_size=10) #epochs = 150

y_pred = model.predict(X_test)

print(y_test, y_pred)